package com.ems.ServiceImplementions;

import java.util.List;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ems.Entity.DepartmentEntity;
import com.ems.Entity.SubDepartmentEntity;
import com.ems.Exception.DepartmentNotFoundException;
import com.ems.Exception.SubDepartmentNotFoundException;
import com.ems.Repo.DepartmentRepository;
import com.ems.Repo.SubDepartmentRepository;
import com.ems.Service.SubDepartmentService;
import com.ems.dto.SubDepartmentDto;

@Service
public class SubDepartmentServiceImpl implements SubDepartmentService {

	    @Autowired
	    private  SubDepartmentRepository subDepartmentRepository;
	    @Autowired
	    private  DepartmentRepository departmentRepository;

	    @Override
	    public SubDepartmentEntity saveSubDepartment(SubDepartmentDto subDepartmentDto, int departmentId) {
	        DepartmentEntity department = departmentRepository.findById(departmentId)
	                .orElseThrow(() -> new DepartmentNotFoundException(departmentId));

	        SubDepartmentEntity subDepartment = new SubDepartmentEntity();
	        subDepartment.setSubDepartmentName(subDepartmentDto.getSubDepartmentName());
	        subDepartment.setSubDepartmentDescription(subDepartmentDto.getSubDepartmentDescription());
	        subDepartment.setParentDepartment(department);

	        return subDepartmentRepository.save(subDepartment);
	    }
	
	    @Override
	    public SubDepartmentEntity updateSubDepartment(Long subDepartmentId, SubDepartmentDto subDepartmentDto) {
	        SubDepartmentEntity existingSubDepartment = subDepartmentRepository.findById(subDepartmentId)
	                .orElseThrow(() -> new SubDepartmentNotFoundException(subDepartmentId));

	        existingSubDepartment.setSubDepartmentName(subDepartmentDto.getSubDepartmentName());
	        existingSubDepartment.setSubDepartmentDescription(subDepartmentDto.getSubDepartmentDescription());

	        return subDepartmentRepository.save(existingSubDepartment);
	    }

	    
	    @Override
	    public String deleteSubDepartment(Long subDepartmentId) {
	        if (!subDepartmentRepository.existsById(subDepartmentId)) {
	            throw new SubDepartmentNotFoundException(subDepartmentId);
	        }
	        subDepartmentRepository.deleteById(subDepartmentId);
	        return "Sub-department deleted successfully with ID: " + subDepartmentId;
	    }

	    @Override
	    public List<SubDepartmentDto> getAllSubDepartments() {
	        List<SubDepartmentEntity> subDepartments = subDepartmentRepository.findAll();
	        return subDepartments.stream()
	                .map(this::mapToDto)
	                .collect(Collectors.toList());
	    }

	    @Override
	    public SubDepartmentDto getSubDepartmentDtoById(Long subDepartmentId) {
	        SubDepartmentEntity subDepartmentEntity = subDepartmentRepository.findById(subDepartmentId)
	                .orElseThrow(() -> new SubDepartmentNotFoundException(subDepartmentId));

	        return mapToDto(subDepartmentEntity);
	    }

	    private SubDepartmentDto mapToDto(SubDepartmentEntity subDepartment) {
	        SubDepartmentDto subDepartmentDto = new SubDepartmentDto();
	        subDepartmentDto.setSubDepartmentId(subDepartment.getSubDepartmentId());
	        subDepartmentDto.setSubDepartmentName(subDepartment.getSubDepartmentName());
	        subDepartmentDto.setSubDepartmentDescription(subDepartment.getSubDepartmentDescription());
	        subDepartmentDto.setDepartmentId(subDepartment.getParentDepartment().getDepartmentId());

	        return subDepartmentDto;
	    }
}
