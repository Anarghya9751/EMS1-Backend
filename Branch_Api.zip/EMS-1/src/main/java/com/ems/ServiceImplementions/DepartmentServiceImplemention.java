package com.ems.ServiceImplementions;

import java.util.List;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ems.Entity.BranchEntity;
import com.ems.Entity.DepartmentEntity;
import com.ems.Entity.OrganizationEntity;
import com.ems.Exception.BranchNotFoundException;
import com.ems.Exception.DepartmentNotFoundException;
import com.ems.Exception.OrganizationNotFoundException;
import com.ems.Repo.BranchRepository;
import com.ems.Repo.DepartmentRepository;
import com.ems.Repo.OrganizationRepository;
import com.ems.Service.DepartmentService;
import com.ems.dto.BranchForm;
import com.ems.dto.DepartmentDto;
@Service
public class DepartmentServiceImplemention implements DepartmentService {

	     @Autowired
	    private DepartmentRepository departmentRepository;

	    @Autowired
	    private BranchRepository branchRepository;

	    @Autowired
	    private OrganizationRepository organizationRepository;

	    @Override
	    public DepartmentEntity saveDepartment(DepartmentEntity departmentEntity, Long organizationId, Integer branchId) {
	        OrganizationEntity organization = organizationRepository.findById(organizationId)
	                .orElseThrow(() -> new OrganizationNotFoundException(organizationId));
	        
	        BranchEntity branch = branchRepository.findById(branchId)
	                .orElseThrow(() -> new BranchNotFoundException(branchId));
	        
	        departmentEntity.setOrganization(organization);
	        departmentEntity.setBranch(branch);
	        
	        return departmentRepository.save(departmentEntity);
	    }
	   
	    @Override
	    public String deleteById(int departmentId) {
	        if (!departmentRepository.existsById(departmentId)) {
	            throw new DepartmentNotFoundException(departmentId);
	        }
	        departmentRepository.deleteById(departmentId);
	        return "Department deleted successfully with ID: " + departmentId;
	    }
	    
//	    @Override
//	    public DepartmentEntity updateDepartment(int departmentId, DepartmentEntity departmentEntity) {
//	        DepartmentEntity existingDepartment = departmentRepository.findById(departmentId)
//	                .orElseThrow(() -> new DepartmentNotFoundException(departmentId));
//	        
//	        existingDepartment.setDepartmentname(departmentEntity.getDepartmentname());
//	        existingDepartment.setDepartmentDescription(departmentEntity.getDepartmentDescription());
//	        existingDepartment.setBranch(departmentEntity.getBranch());
//	        existingDepartment.setOrganization(departmentEntity.getOrganization());
//	        
//	        departmentRepository.save(existingDepartment);
//	        return existingDepartment;
//	    }
	    
	    public DepartmentEntity updateDepartment(int departmentId, DepartmentEntity departmentEntity) 
	    {
	    	
	        DepartmentEntity existingDepartment = departmentRepository.findById(departmentId)
	                .orElseThrow(() -> new DepartmentNotFoundException(departmentId));
            existingDepartment.setDepartmentname(departmentEntity.getDepartmentname());
	        existingDepartment.setDepartmentDescription(departmentEntity.getDepartmentDescription());
	        existingDepartment.setBranch(departmentEntity.getBranch());
	        existingDepartment.setOrganization(departmentEntity.getOrganization());
            return departmentRepository.save(existingDepartment);
	        
	    }
	    
	    @Override
	    public DepartmentDto getDepartmentDtoById(int departmentId) {
	        DepartmentEntity departmentEntity = departmentRepository.findById(departmentId)
	                .orElseThrow(() -> new DepartmentNotFoundException(departmentId));
	        
	        DepartmentDto departmentDto = new DepartmentDto();
	        departmentDto.setDepartmentId(departmentEntity.getDepartmentId());
	        departmentDto.setDepartmentname(departmentEntity.getDepartmentname());
	        departmentDto.setDepartmentDescription(departmentEntity.getDepartmentDescription());
	        departmentDto.setOrganizationId(departmentEntity.getOrganization().getOrganizationId());
	        departmentDto.setBranchId(departmentEntity.getBranch().getBranchId());
	        
	        return departmentDto;
	    }
	    
	    @Override
		public List<DepartmentDto> getAllDepartments() 
	    {
		    List<DepartmentEntity> departments = departmentRepository.findAll();
		    return departments.stream()
		            .map(this::mapToDto)
		            .collect(Collectors.toList());
		}

		private DepartmentDto mapToDto(DepartmentEntity department)
		{
		    DepartmentDto departmentDto = new DepartmentDto();
		    departmentDto.setDepartmentId(department.getDepartmentId());
		    departmentDto.setDepartmentname(department.getDepartmentname());
		    departmentDto.setDepartmentDescription(department.getDepartmentDescription());
		    departmentDto.setOrganizationId(department.getOrganization().getOrganizationId());
		    departmentDto.setBranchId(department.getBranch().getBranchId());
		    

		    
		    return departmentDto;
		}
		
		public DepartmentEntity updateDepartment(Long organizationId, Integer branchId, Integer departmentId, DepartmentDto departmentDto) {
	        OrganizationEntity organization = organizationRepository.findById(organizationId)
	                .orElseThrow(() -> new OrganizationNotFoundException(organizationId));

	        BranchEntity branch = branchRepository.findById(branchId)
	                .orElseThrow(() -> new BranchNotFoundException(branchId));

	        DepartmentEntity existingDepartment = departmentRepository.findById(departmentId)
	                .orElseThrow(() -> new DepartmentNotFoundException(departmentId));

	        if (!existingDepartment.getOrganization().equals(organization) || !existingDepartment.getBranch().equals(branch)) {
	            throw new DepartmentNotFoundException(departmentId);
	        }

	        existingDepartment.setDepartmentname(departmentDto.getDepartmentname());
	        existingDepartment.setDepartmentDescription(departmentDto.getDepartmentDescription());
	        existingDepartment.setBranch(branch);
	        existingDepartment.setOrganization(organization);

	        return departmentRepository.save(existingDepartment);
	    }


}
