package com.ems.Service;

import java.util.List;

import com.ems.Entity.DepartmentEntity;
import com.ems.dto.DepartmentDto;



public interface DepartmentService {

    public DepartmentEntity saveDepartment(DepartmentEntity departmentEntity, Long organizationId, Integer branchId);

    public String deleteById(int departmentId) ;

    public DepartmentEntity updateDepartment(int departmentId, DepartmentEntity departmentEntity);

    public DepartmentDto getDepartmentDtoById(int departmentId) ;
    
	public List<DepartmentDto> getAllDepartments() ;
	
	public DepartmentEntity updateDepartment(Long organizationId, Integer branchId, Integer departmentId, DepartmentDto departmentDto);



}
