package com.ems.Service;

import java.util.List;

import com.ems.Entity.SubDepartmentEntity;
import com.ems.dto.SubDepartmentDto;

public interface SubDepartmentService {

	SubDepartmentEntity saveSubDepartment(SubDepartmentDto subDepartmentDto, int departmentId);

    SubDepartmentEntity updateSubDepartment(Long subDepartmentId, SubDepartmentDto subDepartmentDto);

    String deleteSubDepartment(Long subDepartmentId);

    List<SubDepartmentDto> getAllSubDepartments();

    SubDepartmentDto getSubDepartmentDtoById(Long subDepartmentId);
}
