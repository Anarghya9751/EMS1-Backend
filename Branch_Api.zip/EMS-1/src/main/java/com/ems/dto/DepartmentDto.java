package com.ems.dto;

public class DepartmentDto {

    private int departmentId;
    private String Departmentname;
    private String DepartmentDescription;
    private Long organizationId;
    private int branchId;
    
    
    
    
	public int getDepartmentId() {
		return departmentId;
	}
	public void setDepartmentId(int departmentId) {
		this.departmentId = departmentId;
	}
	public String getDepartmentname() {
		return Departmentname;
	}
	public void setDepartmentname(String departmentname) {
		Departmentname = departmentname;
	}
	public String getDepartmentDescription() {
		return DepartmentDescription;
	}
	public void setDepartmentDescription(String departmentDescription) {
		DepartmentDescription = departmentDescription;
	}
	public Long getOrganizationId() {
		return organizationId;
	}
	public void setOrganizationId(Long organizationId) {
		this.organizationId = organizationId;
	}
	public int getBranchId() {
		return branchId;
	}
	public void setBranchId(int branchId) {
		this.branchId = branchId;
	}
    


}
